"""
Soal 11.26 - Program Gauss-Seidel (User-Friendly)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Buat program Gauss-Seidel (berdasarkan Fig. 11.6).
Uji dengan menduplikasi hasil Example 11.3.

Example 11.3 (dari buku):
 0.8x1 + 0.2x2 - 0.4x3 = 41
-0.4x1 + 0.8x2 + 0.0x3 = 25
 0.0x1 - 0.4x2 + 0.8x3 = 105
"""

import numpy as np


def gauss_seidel_solver(A, b, x0=None, tol=1.0, max_iter=100,
                         lam=1.0, verbose=True):
    """
    Gauss-Seidel Successive Over-Relaxation (SOR) Solver.
    Berdasarkan Fig. 11.6 dari buku Chapra.

    Parameter:
        A       : matriks koefisien (n x n)
        b       : vektor RHS (n)
        x0      : tebakan awal (default: zeros)
        tol     : toleransi error relatif (%)
        max_iter: batas iterasi
        lam     : faktor relaksasi (default 1.0 = Gauss-Seidel murni)
        verbose : cetak tabel iterasi

    Return:
        x       : solusi akhir
        n_iter  : jumlah iterasi
        errors  : list error per iterasi
    """
    n = len(b)
    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)
    errors = []

    if verbose:
        header = f"{'Iter':>4}  " + "  ".join(f"{'x'+str(i+1):>12}" for i in range(n)) + f"  {'Error%':>10}"
        print(header)
        print("-" * len(header))

    for it in range(1, max_iter + 1):
        x_old = x.copy()

        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x_gs = (b[i] - sigma) / A[i, i]
            x[i] = lam * x_gs + (1 - lam) * x_old[i]

        # Error relatif maksimum
        with np.errstate(divide='ignore', invalid='ignore'):
            err = np.max(np.abs(np.where(x != 0, (x - x_old) / x, 0))) * 100
        errors.append(err)

        if verbose:
            vals = "  ".join(f"{xi:>12.6f}" for xi in x)
            print(f"{it:>4}  {vals}  {err:>10.4f}")

        if err < tol:
            break

    return x, it, errors


# ── Test: Example 11.3 ───────────────────────────────
print("=" * 65)
print("Soal 11.26 — Program Gauss-Seidel (εs = 5%)")
print("=" * 65)

A = np.array([
    [ 0.8, -0.4,  0.0],
    [-0.4,  0.8, -0.4],
    [ 0.0, -0.4,  0.8]
])
b = np.array([41.0, 25.0, 105.0])

print("\nTest dengan sistem dari Soal 11.1 (mirip Example 11.3):")
x, n_iter, errors = gauss_seidel_solver(A, b, tol=5.0, lam=1.0)

print(f"\nSolusi setelah {n_iter} iterasi:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.6f}")

x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for i, xi in enumerate(x_exact, 1):
    print(f"  x{i} = {xi:.6f}")
print("=" * 65)
