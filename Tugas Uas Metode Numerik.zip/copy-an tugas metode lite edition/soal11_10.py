"""
Soal 11.10 - Jacobi Iteration
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Ulangi Soal 11.9 tetapi gunakan Jacobi iteration.

Sistem (sama dengan 11.9):
15c1 -  3c2 -   c3 = 3300
-3c1 + 18c2 -  6c3 = 1200
-4c1 -   c2 + 12c3 = 2400
"""

import numpy as np


def jacobi(A, b, tol=5.0, max_iter=100):
    """
    Jacobi iteration — semua update menggunakan nilai dari iterasi SEBELUMNYA.
    (Berbeda dengan Gauss-Seidel yang langsung pakai nilai terbaru)
    """
    n = len(b)
    x = np.zeros(n)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        x_new = np.zeros(n)

        for i in range(n):
            sigma = sum(A[i, j] * x_old[j] for j in range(n) if j != i)
            x_new[i] = (b[i] - sigma) / A[i, i]

        err = np.max(np.abs((x_new - x_old) / (x_new + 1e-15))) * 100
        x = x_new
        history.append({'iter': it, 'x': x.copy(), 'err': err})

        if err < tol:
            print(f"  Konvergen pada iterasi {it}, error = {err:.4f}%")
            break

    return x, history


# ── Data soal ────────────────────────────────────────
A = np.array([
    [ 15, -3,  -1],
    [ -3, 18,  -6],
    [ -4, -1,  12]
], dtype=float)
b = np.array([3300, 1200, 2400], dtype=float)

print("=" * 60)
print("Soal 11.10 — Jacobi Iteration")
print("=" * 60)
print("\nIterasi Jacobi (εs = 5%):")
x, history = jacobi(A, b, tol=5.0)

print(f"\n{'Iter':>4}  {'c1':>12}  {'c2':>12}  {'c3':>12}  {'Error%':>10}")
print("-" * 57)
for h in history:
    print(f"{h['iter']:>4}  {h['x'][0]:>12.4f}  {h['x'][1]:>12.4f}  {h['x'][2]:>12.4f}  {h['err']:>10.4f}")

print("\nSolusi akhir (konsentrasi g/m³):")
for name, val in zip(['c1', 'c2', 'c3'], x):
    print(f"  {name} = {val:.4f} g/m³")

x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for name, val in zip(['c1', 'c2', 'c3'], x_exact):
    print(f"  {name} = {val:.4f} g/m³")

print("\nCatatan: Jacobi umumnya konvergen lebih lambat dari Gauss-Seidel")
print("karena tidak langsung menggunakan nilai terbaru dalam satu iterasi.")
print("=" * 60)
