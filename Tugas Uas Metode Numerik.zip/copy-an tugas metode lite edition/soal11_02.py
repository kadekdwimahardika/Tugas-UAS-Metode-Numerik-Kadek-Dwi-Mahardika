"""
Soal 11.2 - Matrix Inverse via LU Decomposition
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Tentukan invers matriks dari sistem pada Example 11.1
menggunakan LU decomposition dan unit vectors.

Matriks dari Example 11.1 (tridiagonal):
[ 0.8  -0.4   0  ]
[-0.4   0.8  -0.4]
[ 0    -0.4   0.8]
"""

import numpy as np
from scipy.linalg import lu, solve_triangular


def lu_inverse(A):
    """
    Hitung invers matriks menggunakan LU decomposition + unit vectors.

    Untuk setiap unit vector e_i, selesaikan A * x_i = e_i.
    Kolom-kolom x_i membentuk A^-1.
    """
    n = A.shape[0]
    P, L, U = lu(A)
    A_inv = np.zeros((n, n))

    for i in range(n):
        # Unit vector e_i
        e = np.zeros(n)
        e[i] = 1.0

        # Selesaikan L*y = P*e (forward substitution)
        y = solve_triangular(L, P @ e, lower=True)

        # Selesaikan U*x = y (back substitution)
        x = solve_triangular(U, y, lower=False)

        A_inv[:, i] = x

    return A_inv


# ── Data soal ────────────────────────────────────────
A = np.array([
    [ 0.8, -0.4,  0.0],
    [-0.4,  0.8, -0.4],
    [ 0.0, -0.4,  0.8]
])

# ── Hitung inverse ───────────────────────────────────
A_inv = lu_inverse(A)

print("=" * 50)
print("Soal 11.2 — Matrix Inverse via LU Decomposition")
print("=" * 50)
print("\nMatriks A:")
print(A)
print("\nInvers A (via LU + unit vectors):")
print(np.round(A_inv, 6))

# Verifikasi: A * A^-1 harus = I
I_check = A @ A_inv
print("\nVerifikasi A @ A_inv (harus = I):")
print(np.round(I_check, 6))

# Bandingkan dengan numpy
A_inv_np = np.linalg.inv(A)
print("\nInvers A (numpy.linalg.inv):")
print(np.round(A_inv_np, 6))
print(f"\nSelisih max: {np.max(np.abs(A_inv - A_inv_np)):.2e}")
print("=" * 50)
