"""
Soal 11.9 - Gauss-Seidel: Sistem Reaktor Kimia
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Selesaikan sistem berikut dengan Gauss-Seidel (εs = 5%):
15c1 -  3c2 -   c3 = 3300
-3c1 + 18c2 -  6c3 = 1200
-4c1 -   c2 + 12c3 = 2400

(konsentrasi dalam g/m³ pada reaktor-reaktor yang terhubung)
"""

import numpy as np


def gauss_seidel(A, b, tol=5.0, max_iter=100):
    n = len(b)
    x = np.zeros(n)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x[i] = (b[i] - sigma) / A[i, i]

        err = np.max(np.abs((x - x_old) / (x + 1e-15))) * 100
        history.append({'iter': it, 'x': x.copy(), 'err': err})

        if err < tol:
            print(f"  Konvergen pada iterasi {it}, error = {err:.4f}%")
            break

    return x, history


# ── Data soal ────────────────────────────────────────
A = np.array([
    [ 15, -3,  -1],
    [ -3, 18,  -6],
    [ -4, -1,  12]
], dtype=float)
b = np.array([3300, 1200, 2400], dtype=float)

# Cek diagonal dominance
print("=" * 55)
print("Soal 11.9 — Gauss-Seidel: Reaktor Kimia")
print("=" * 55)
diag_dom = all(abs(A[i, i]) >= sum(abs(A[i, j]) for j in range(3) if j != i)
               for i in range(3))
print(f"\nDiagonal dominant? {diag_dom} → Gauss-Seidel akan konvergen")

print("\nIterasi Gauss-Seidel (εs = 5%):")
x, history = gauss_seidel(A, b, tol=5.0)

print(f"\n{'Iter':>4}  {'c1':>12}  {'c2':>12}  {'c3':>12}  {'Error%':>10}")
print("-" * 57)
for h in history:
    print(f"{h['iter']:>4}  {h['x'][0]:>12.4f}  {h['x'][1]:>12.4f}  {h['x'][2]:>12.4f}  {h['err']:>10.4f}")

print("\nSolusi akhir (konsentrasi g/m³):")
for name, val in zip(['c1', 'c2', 'c3'], x):
    print(f"  {name} = {val:.4f} g/m³")

x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for name, val in zip(['c1', 'c2', 'c3'], x_exact):
    print(f"  {name} = {val:.4f} g/m³")
print("=" * 55)
