"""
Soal 11.14 - Analisis Geometris Gauss-Seidel (Deskriptif)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Gambar ulang Fig. 11.5 untuk kasus slope = 1 dan -1.
Apa yang terjadi jika Gauss-Seidel diterapkan pada sistem seperti ini?

=== JAWABAN ===

Fig. 11.5 menggambarkan dua persamaan linear sebagai garis pada bidang 2D,
dan Gauss-Seidel bekerja dengan proyeksi horizontal dan vertikal bergantian
menuju titik potong (solusi).

Kasus slope = 1 dan -1:
  Persamaan 1: y =  x + c1  (slope +1)
  Persamaan 2: y = -x + c2  (slope -1)

Geometri:
  - Kedua garis saling tegak lurus (slope 1 dan -1)
  - Titik potong ada SATU (sistem konsisten)
  - Gauss-Seidel: pada setiap iterasi, proyeksi horisontal/vertikal
    akan melompat dari satu garis ke garis lain

Hasil penerapan Gauss-Seidel:
  - Jika |slope| < 1 (untuk bentuk iterasi yang digunakan), KONVERGEN.
  - Pada kasus slope = 1 dan -1, iterasi akan berosilasi (ping-pong)
    di sekitar solusi, tetapi TIDAK konvergen — setiap iterasi memiliki
    error yang sama besarnya.
  - Ini terjadi karena radius spektral matriks iterasi = 1, yang merupakan
    batas kritis antara konvergen dan divergen.

Kesimpulan:
  Gauss-Seidel TIDAK akan konvergen untuk sistem dengan slope ±1
  karena kondisi ini tepat di batas syarat konvergensi diagonal dominant.
"""

import numpy as np
import matplotlib.pyplot as plt

# Ilustrasi visual: dua garis dengan slope 1 dan -1
x_vals = np.linspace(-5, 5, 200)

# Contoh: x + y = 4  dan  -x + y = 0  → solusi (2, 2)
# y =  -x + 4 (slope -1) dari persamaan 1: x + y = 4
# y =   x + 0 (slope +1) dari persamaan 2: -x + y = 0

y1 = -x_vals + 4   # slope -1
y2 =  x_vals       # slope +1

fig, ax = plt.subplots(figsize=(6, 6))
ax.plot(x_vals, y1, 'b-', label='x + y = 4 (slope = -1)')
ax.plot(x_vals, y2, 'r-', label='-x + y = 0 (slope = +1)')
ax.plot(2, 2, 'ko', markersize=10, label='Solusi (2,2)')

# Simulasi Gauss-Seidel oscillation
x_gs, y_gs = 0.0, 0.0
pts = [(x_gs, y_gs)]
for _ in range(8):
    # Update x dari persamaan 1: x = 4 - y
    x_gs = 4 - y_gs
    pts.append((x_gs, y_gs))
    # Update y dari persamaan 2: y = x
    y_gs = x_gs
    pts.append((x_gs, y_gs))

xs_path, ys_path = zip(*pts)
ax.plot(xs_path, ys_path, 'g--o', markersize=5, label='Jalur Gauss-Seidel')

ax.set_xlim(-1, 5)
ax.set_ylim(-1, 5)
ax.axhline(0, color='k', linewidth=0.5)
ax.axvline(0, color='k', linewidth=0.5)
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('Soal 11.14: Gauss-Seidel dengan slope ±1')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('figures/fig11_14_gauss_seidel_slopes.png', dpi=120)
plt.show()
print("Plot disimpan ke figures/fig11_14_gauss_seidel_slopes.png")
