"""
Soal 11.25 - Program Cholesky Decomposition (User-Friendly)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Buat program Cholesky decomposition (berdasarkan Fig. 11.3).
Uji dengan menduplikasi hasil Example 11.2.

Example 11.2:
[A] = [6   15   55 ]   b = [152.6 ]
      [15  55   225]       [585.6 ]
      [55  225  979]       [2488.8]
"""

import numpy as np
from scipy.linalg import solve_triangular


def cholesky_decompose(A, verbose=False):
    """
    Cholesky decomposition: A = L @ L^T
    Berdasarkan Fig. 11.3 buku Chapra.

    Parameter:
        A       : matriks simetris positif definit
        verbose : tampilkan langkah detail

    Return:
        L : matriks lower triangular
    """
    n = A.shape[0]
    L = np.zeros((n, n), dtype=float)

    if verbose:
        print("\n--- Langkah Cholesky Decomposition ---")

    for k in range(n):
        # Diagonal (Eq. 11.4)
        inner = sum(L[k, j]**2 for j in range(k))
        L[k, k] = np.sqrt(A[k, k] - inner)
        if verbose:
            print(f"  L[{k+1},{k+1}] = sqrt({A[k,k]:.4f} - {inner:.4f}) = {L[k,k]:.6f}")

        # Off-diagonal (Eq. 11.3)
        for i in range(k + 1, n):
            inner2 = sum(L[i, j] * L[k, j] for j in range(k))
            L[i, k] = (A[i, k] - inner2) / L[k, k]
            if verbose:
                print(f"  L[{i+1},{k+1}] = ({A[i,k]:.4f} - {inner2:.4f}) / {L[k,k]:.4f} = {L[i,k]:.6f}")

    return L


def cholesky_solve(L, b):
    """Selesaikan A x = b dengan L dari Cholesky (A = L @ L^T)."""
    y = solve_triangular(L, b, lower=True)
    x = solve_triangular(L.T, y, lower=False)
    return x


# ── Test: Example 11.2 ───────────────────────────────
print("=" * 55)
print("Soal 11.25 — Program Cholesky Decomposition")
print("=" * 55)
print("\nTest dengan Example 11.2:")

A = np.array([
    [  6,  15,   55],
    [ 15,  55,  225],
    [ 55, 225,  979]
], dtype=float)
b = np.array([152.6, 585.6, 2488.8])

L = cholesky_decompose(A, verbose=True)

print(f"\nMatriks L:")
print(np.round(L, 6))
print(f"\nVerifikasi L @ L^T = A: {np.allclose(L @ L.T, A)}")

x = cholesky_solve(L, b)
print(f"\nSolusi (a0, a1, a2):")
for name, val in zip(['a0', 'a1', 'a2'], x):
    print(f"  {name} = {val:.6f}")

print(f"\nVerifikasi A @ x = b: {np.allclose(A @ x, b)}")
print("=" * 55)
