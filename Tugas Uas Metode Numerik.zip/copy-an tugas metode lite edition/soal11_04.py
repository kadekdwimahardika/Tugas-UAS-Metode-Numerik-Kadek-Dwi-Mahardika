"""
Soal 11.4 - Verifikasi Cholesky Decomposition (Example 11.2)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Konfirmasi validitas Cholesky decomposition dari Example 11.2
dengan cara mensubstitusikan hasil ke Eq. (11.2): [A] = [L][L]^T

Matriks dari Example 11.2:
[A] = [6  15  55]
      [15  55  225]
      [55  225  979]
"""

import numpy as np


def cholesky_manual(A):
    """
    Cholesky decomposition manual: A = L @ L.T
    Menggunakan persamaan 11.3 dan 11.4 dari buku.
    """
    n = A.shape[0]
    L = np.zeros_like(A, dtype=float)

    for k in range(n):
        # Diagonal element (Eq 11.4)
        L[k, k] = np.sqrt(A[k, k] - sum(L[k, j]**2 for j in range(k)))

        # Off-diagonal elements (Eq 11.3)
        for i in range(k + 1, n):
            L[i, k] = (A[i, k] - sum(L[i, j] * L[k, j] for j in range(k))) / L[k, k]

    return L


# ── Data dari Example 11.2 ───────────────────────────
A = np.array([
    [  6,  15,   55],
    [ 15,  55,  225],
    [ 55, 225,  979]
], dtype=float)

# ── Hitung Cholesky ──────────────────────────────────
L = cholesky_manual(A)

print("=" * 50)
print("Soal 11.4 — Verifikasi Cholesky Decomposition")
print("=" * 50)
print("\nMatriks L (lower triangular):")
print(np.round(L, 6))

print("\nMatriks L^T:")
print(np.round(L.T, 6))

# Verifikasi: L @ L^T harus = A
A_reconstructed = L @ L.T
print("\nHasil L @ L^T (harus = A):")
print(np.round(A_reconstructed, 6))

print("\nMatriks A asli:")
print(A)

print(f"\nSelisih max |A - L@L^T|: {np.max(np.abs(A - A_reconstructed)):.2e}")
print("\nKesimpulan: Cholesky decomposition VALID ✓" if np.allclose(A, A_reconstructed) else "ERROR!")
print("=" * 50)
