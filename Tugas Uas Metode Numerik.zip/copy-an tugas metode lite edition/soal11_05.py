"""
Soal 11.5 - Cholesky Decomposition + Solve
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Lakukan Cholesky decomposition untuk sistem simetris berikut,
kemudian gunakan untuk menyelesaikan sistem:

[6   15   55 ] [a0]   [152.6 ]
[15  55   225] [a1] = [585.6 ]
[55  225  979] [a2]   [2488.8]
"""

import numpy as np
from scipy.linalg import solve_triangular


def cholesky_decompose(A):
    """Cholesky decomposition: A = L @ L.T"""
    n = A.shape[0]
    L = np.zeros_like(A, dtype=float)
    for k in range(n):
        L[k, k] = np.sqrt(A[k, k] - np.sum(L[k, :k]**2))
        for i in range(k + 1, n):
            L[i, k] = (A[i, k] - np.sum(L[i, :k] * L[k, :k])) / L[k, k]
    return L


def cholesky_solve(L, b):
    """
    Selesaikan A*x = b dengan A = L @ L.T
    1. L*y = b  (forward substitution)
    2. L.T*x = y (back substitution)
    """
    y = solve_triangular(L, b, lower=True)
    x = solve_triangular(L.T, y, lower=False)
    return x


# ── Data soal ────────────────────────────────────────
A = np.array([
    [  6,  15,   55],
    [ 15,  55,  225],
    [ 55, 225,  979]
], dtype=float)

b = np.array([152.6, 585.6, 2488.8])

# ── Cholesky decomposition ───────────────────────────
L = cholesky_decompose(A)

print("=" * 50)
print("Soal 11.5 — Cholesky Decomposition + Solve")
print("=" * 50)
print("\nMatriks L:")
print(np.round(L, 6))

# ── Solve ────────────────────────────────────────────
x = cholesky_solve(L, b)
print("\nSolusi (a0, a1, a2):")
for name, val in zip(['a0', 'a1', 'a2'], x):
    print(f"  {name} = {val:.6f}")

# Verifikasi
print("\nVerifikasi A @ x:")
print(f"  Hasil : {A @ x}")
print(f"  Target: {b}")
print(f"\nSelisih max: {np.max(np.abs(A @ x - b)):.2e}")
print("=" * 50)
