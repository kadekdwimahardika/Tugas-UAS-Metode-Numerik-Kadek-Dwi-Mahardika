"""
Soal 11.8 - Gauss-Seidel dengan Overrelaxation
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Gunakan Gauss-Seidel untuk menyelesaikan sistem tridiagonal dari Soal 11.1
dengan toleransi εs = 5% dan overrelaxation λ = 1.2.

Sistem:
[ 0.8  -0.4   0  ] [x1]   [ 41 ]
[-0.4   0.8  -0.4] [x2] = [ 25 ]
[ 0    -0.4   0.8] [x3]   [105 ]
"""

import numpy as np


def gauss_seidel(A, b, x0=None, tol=0.05, max_iter=100, lam=1.0):
    """
    Gauss-Seidel dengan overrelaxation (SOR).

    Parameter:
        A       : matriks koefisien
        b       : vektor RHS
        x0      : tebakan awal (default: zeros)
        tol     : toleransi error relatif (%)
        max_iter: iterasi maksimum
        lam     : faktor relaksasi (lam=1 = Gauss-Seidel biasa)

    Return:
        x       : solusi
        history : riwayat iterasi
    """
    n = len(b)
    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()

        for i in range(n):
            # Hitung nilai baru Gauss-Seidel
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x_gs = (b[i] - sigma) / A[i, i]
            # Terapkan relaxation
            x[i] = lam * x_gs + (1 - lam) * x_old[i]

        # Hitung error relatif max
        err = np.max(np.abs((x - x_old) / (x + 1e-15))) * 100
        history.append({'iter': it, 'x': x.copy(), 'err': err})

        if err < tol:
            print(f"  Konvergen pada iterasi {it}, error = {err:.4f}%")
            break
    else:
        print(f"  Tidak konvergen dalam {max_iter} iterasi")

    return x, history


# ── Data soal ────────────────────────────────────────
A = np.array([
    [ 0.8, -0.4,  0.0],
    [-0.4,  0.8, -0.4],
    [ 0.0, -0.4,  0.8]
])
b = np.array([41.0, 25.0, 105.0])

print("=" * 55)
print("Soal 11.8 — Gauss-Seidel + Overrelaxation (λ=1.2)")
print("=" * 55)
print("\nIterasi Gauss-Seidel (εs=5%, λ=1.2):")

x, history = gauss_seidel(A, b, tol=5.0, lam=1.2)

print(f"\n{'Iter':>4}  {'x1':>12}  {'x2':>12}  {'x3':>12}  {'Error%':>10}")
print("-" * 57)
for h in history:
    print(f"{h['iter']:>4}  {h['x'][0]:>12.6f}  {h['x'][1]:>12.6f}  {h['x'][2]:>12.6f}  {h['err']:>10.4f}")

print("\nSolusi akhir:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.6f}")

# Solusi eksak
x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak (numpy):")
for i, xi in enumerate(x_exact, 1):
    print(f"  x{i} = {xi:.6f}")
print("=" * 55)
