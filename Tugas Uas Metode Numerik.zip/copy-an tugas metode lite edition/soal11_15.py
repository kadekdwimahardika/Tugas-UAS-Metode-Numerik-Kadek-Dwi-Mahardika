"""
Soal 11.15 - Uji Konvergensi Gauss-Seidel (3 Set Persamaan)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Dari tiga set persamaan berikut, identifikasi mana yang TIDAK bisa
diselesaikan dengan metode iteratif (Gauss-Seidel).

Set 1:  9x + 3y +  z = 13    Set 2:  x +  y + 6z = 8    Set 3: -3x + 4y + 5z = 6
       -6x +      8z = 2             x + 5y -  z = 5            -2x + 2y - 4z = -3
        2x + 5y -  z = 6             4x + 2y - 2z = 4             2y -  z = 1
"""

import numpy as np


def gauss_seidel(A, b, tol=1e-6, max_iter=50):
    n = len(b)
    x = np.zeros(n)
    errors = []

    for it in range(max_iter):
        x_old = x.copy()
        for i in range(n):
            if abs(A[i, i]) < 1e-15:
                return x, errors, False
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x[i] = (b[i] - sigma) / A[i, i]

        err = np.max(np.abs(x - x_old))
        errors.append(err)
        if err < tol:
            return x, errors, True

    return x, errors, False


def check_diagonal_dominance(A, name):
    n = A.shape[0]
    dominant = True
    for i in range(n):
        off = sum(abs(A[i, j]) for j in range(n) if j != i)
        if abs(A[i, i]) < off:
            dominant = False
    print(f"  {name}: diagonal dominant = {dominant}")
    return dominant


print("=" * 65)
print("Soal 11.15 — Uji Konvergensi Gauss-Seidel (3 Set)")
print("=" * 65)

# ── Set 1 ────────────────────────────────────────────
A1 = np.array([
    [ 9, 3,  1],
    [-6, 0,  8],
    [ 2, 5, -1]
], dtype=float)
b1 = np.array([13, 2, 6], dtype=float)

# ── Set 2 ────────────────────────────────────────────
A2 = np.array([
    [1, 1,  6],
    [1, 5, -1],
    [4, 2, -2]
], dtype=float)
b2 = np.array([8, 5, 4], dtype=float)

# ── Set 3 ────────────────────────────────────────────
A3 = np.array([
    [-3, 4,  5],
    [-2, 2, -4],
    [ 0, 2, -1]
], dtype=float)
b3 = np.array([6, -3, 1], dtype=float)

datasets = [("Set 1", A1, b1), ("Set 2", A2, b2), ("Set 3", A3, b3)]

print("\nCek Diagonal Dominance:")
for name, A, b in datasets:
    check_diagonal_dominance(A, name)

print("\nHasil Gauss-Seidel (50 iterasi):")
for name, A, b in datasets:
    x, errors, converged = gauss_seidel(A, b)
    x_exact = np.linalg.solve(A, b)
    print(f"\n  {name}:")
    print(f"    Konvergen: {converged}")
    print(f"    Solusi GS    : {np.round(x, 4)}")
    print(f"    Solusi eksak : {np.round(x_exact, 4)}")
    if not converged and len(errors) > 2:
        trend = "divergen" if errors[-1] > errors[-2] else "berosilasi"
        print(f"    Tren error: {trend} (error terakhir = {errors[-1]:.4f})")

print("""
Kesimpulan:
  - Set yang TIDAK konvergen adalah yang tidak diagonal dominant.
  - Diagonal dominance: |A[i,i]| >= sum(|A[i,j]|) untuk semua i (j≠i)
  - Gauss-Seidel dijamin konvergen jika diagonal dominant.
""")
print("=" * 65)
