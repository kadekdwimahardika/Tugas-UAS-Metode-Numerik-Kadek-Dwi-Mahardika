"""
Soal 11.19 - Hilbert Matrix Condition Number
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Tentukan spectral condition number untuk matriks Hilbert 10x10.
Berapa digit presisi yang hilang akibat ill-conditioning?
Selesaikan sistem untuk b = jumlah koefisien per baris (x = [1,1,...,1]).
"""

import numpy as np


def hilbert_matrix(n):
    """Buat matriks Hilbert n x n: H[i,j] = 1/(i+j-1)"""
    return np.array([[1.0 / (i + j + 1) for j in range(n)] for i in range(n)])


n = 10
H = hilbert_matrix(n)

# RHS: jumlah koefisien tiap baris → solusi x = [1,1,...,1]
b = H.sum(axis=1)

print("=" * 60)
print("Soal 11.19 — Hilbert Matrix 10x10 Condition Number")
print("=" * 60)

# Condition number (spectral = 2-norm)
cond = np.linalg.cond(H)
digits_lost = np.log10(cond)

print(f"\nSpectral condition number: {cond:.4e}")
print(f"Digit presisi yang hilang: ~{digits_lost:.1f} digit")
print(f"(Jika float64 punya ~15 digit, tersisa ~{15 - digits_lost:.1f} digit)")

# Selesaikan sistem
x = np.linalg.solve(H, b)
x_exact = np.ones(n)
error = np.abs(x - x_exact)

print(f"\nSolusi x (harus = 1 semua):")
print(f"  x = {np.round(x, 6)}")
print(f"\nError |x - 1|:")
print(f"  max error = {error.max():.4e}")
print(f"  mean error = {error.mean():.4e}")

print(f"""
Interpretasi:
  Condition number ≈ {cond:.1e}
  log10(cond) ≈ {digits_lost:.1f} → sekitar {digits_lost:.0f} digit presisi hilang.
  Matriks Hilbert sangat ill-conditioned — kecil perubahan pada b
  bisa menyebabkan perubahan besar pada x.
""")
print("=" * 60)
