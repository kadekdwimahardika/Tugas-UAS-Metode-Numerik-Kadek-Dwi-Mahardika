"""
Soal 11.16 - Solve, Inverse, dan Condition Number
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Untuk setiap sistem, hitung: solusi, invers, dan condition number
(berdasarkan row-sum norm, tanpa scaling).

(a) Sistem 3x3:
[1  4  9 ] [x1]   [14]
[4  9  16] [x2] = [29]
[9  16 25] [x3]   [50]

(b) Sistem 4x4:
[1  4  9  16] [x1]   [ 30]
[4  9  16 25] [x2] = [ 54]
[9  16 25 36] [x3]   [ 86]
[16 25 36 49] [x4]   [126]

Jawaban semua x harus = 1.
"""

import numpy as np


def row_sum_norm(A):
    """Row-sum (infinity) norm: max baris dari jumlah |elemen|."""
    return np.max(np.sum(np.abs(A), axis=1))


def condition_number_row_sum(A):
    """Condition number berdasarkan row-sum norm."""
    A_inv = np.linalg.inv(A)
    return row_sum_norm(A) * row_sum_norm(A_inv)


def analyze(label, A, b):
    print(f"\n{'─'*50}")
    print(f"  {label}")
    print(f"{'─'*50}")

    x = np.linalg.solve(A, b)
    print(f"  Solusi x: {np.round(x, 6)}")

    A_inv = np.linalg.inv(A)
    print(f"  Invers A:\n{np.round(A_inv, 6)}")

    cond_rs = condition_number_row_sum(A)
    cond_np = np.linalg.cond(A, np.inf)  # infinity norm = row-sum norm
    print(f"  Condition number (row-sum norm): {cond_rs:.4f}")
    print(f"  Condition number (numpy inf): {cond_np:.4f}")
    print(f"  Verifikasi semua x = 1: {np.allclose(x, 1.0)}")


print("=" * 55)
print("Soal 11.16 — Solve + Inverse + Condition Number")
print("=" * 55)

# (a)
A_a = np.array([
    [ 1,  4,  9],
    [ 4,  9, 16],
    [ 9, 16, 25]
], dtype=float)
b_a = np.array([14, 29, 50], dtype=float)
analyze("(a) Sistem 3x3", A_a, b_a)

# (b)
A_b = np.array([
    [ 1,  4,  9, 16],
    [ 4,  9, 16, 25],
    [ 9, 16, 25, 36],
    [16, 25, 36, 49]
], dtype=float)
b_b = np.array([30, 54, 86, 126], dtype=float)
analyze("(b) Sistem 4x4", A_b, b_b)

print("\nCatatan: Condition number besar → matriks ill-conditioned.")
print("=" * 55)
