"""
Soal 11.6 - Cholesky Decomposition Manual
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Lakukan Cholesky decomposition secara manual untuk:

[ 8  20  15] [x1]   [100]
[20  80  50] [x2] = [250]
[15  50  60] [x3]   [100]
"""

import numpy as np
from scipy.linalg import solve_triangular


def cholesky_decompose(A):
    """Cholesky decomposition step-by-step dengan output detail."""
    n = A.shape[0]
    L = np.zeros((n, n), dtype=float)

    print("\n--- Langkah-langkah Cholesky ---")
    for k in range(n):
        # Diagonal
        inner = np.sum(L[k, :k]**2)
        L[k, k] = np.sqrt(A[k, k] - inner)
        print(f"L[{k+1},{k+1}] = sqrt({A[k,k]} - {inner:.4f}) = {L[k,k]:.6f}")

        # Off-diagonal
        for i in range(k + 1, n):
            inner2 = np.sum(L[i, :k] * L[k, :k])
            L[i, k] = (A[i, k] - inner2) / L[k, k]
            print(f"L[{i+1},{k+1}] = ({A[i,k]} - {inner2:.4f}) / {L[k,k]:.4f} = {L[i,k]:.6f}")

    return L


# ── Data soal ────────────────────────────────────────
A = np.array([
    [ 8, 20, 15],
    [20, 80, 50],
    [15, 50, 60]
], dtype=float)

b = np.array([100, 250, 100], dtype=float)

print("=" * 50)
print("Soal 11.6 — Cholesky Decomposition Manual")
print("=" * 50)
print("\nMatriks A:")
print(A)

# ── Decomposisi ──────────────────────────────────────
L = cholesky_decompose(A)

print("\nMatriks L:")
print(np.round(L, 6))

# Solve
y = solve_triangular(L, b, lower=True)
x = solve_triangular(L.T, y, lower=False)

print("\nSolusi:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.6f}")

print(f"\nVerifikasi A @ x = b: {np.allclose(A @ x, b)}")
print("=" * 50)
