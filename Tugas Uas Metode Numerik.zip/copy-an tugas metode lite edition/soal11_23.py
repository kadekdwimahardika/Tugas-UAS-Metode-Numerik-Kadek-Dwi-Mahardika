"""
Soal 11.23 - Perbandingan Operasi: Thomas vs Gauss Elimination
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Tentukan jumlah operasi Thomas algorithm dan Gauss elimination
sebagai fungsi n (2 sampai 20), lalu buat plotnya.
"""

import numpy as np
import matplotlib.pyplot as plt


def ops_gauss(n):
    """
    Operasi untuk Gauss elimination tanpa partial pivoting:
    Forward elimination: ~(2n³ + 3n² - 5n) / 6  ≈ (2/3)n³
    Back substitution: ~n²
    Total: ≈ (2n³)/3 + n²
    (Chapra Sec 9.2.1: total ≈ (2n³ + 3n² - 5n)/6 + (n² + n)/2)
    """
    return (2*n**3 + 3*n**2 - 5*n) / 6 + (n**2 + n) / 2


def ops_thomas(n):
    """
    Thomas algorithm untuk tridiagonal n×n:
    Forward: 2*(n-1) operasi
    Back sub: 2*(n-1) + 1 operasi
    Total ≈ 5n - 4  (linear!)
    """
    return 5*n - 4


n_vals = np.arange(2, 21)
ops_g = [ops_gauss(n) for n in n_vals]
ops_t = [ops_thomas(n) for n in n_vals]

# ── Tabel ────────────────────────────────────────────
print("=" * 50)
print("Soal 11.23 — Operasi Thomas vs Gauss Elimination")
print("=" * 50)
print(f"\n{'n':>4}  {'Thomas':>10}  {'Gauss':>12}  {'Rasio G/T':>12}")
print("-" * 45)
for n, t, g in zip(n_vals, ops_t, ops_g):
    print(f"{n:>4}  {t:>10.0f}  {g:>12.0f}  {g/t:>12.1f}x")

# ── Plot ─────────────────────────────────────────────
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

ax1.plot(n_vals, ops_g, 'b-o', label='Gauss Elimination O(n³)', linewidth=2)
ax1.plot(n_vals, ops_t, 'r-s', label='Thomas Algorithm O(n)', linewidth=2)
ax1.set_xlabel('n (ukuran sistem)')
ax1.set_ylabel('Jumlah Operasi')
ax1.set_title('Operasi: Thomas vs Gauss Elimination')
ax1.legend()
ax1.grid(True, alpha=0.4)

ax2.semilogy(n_vals, ops_g, 'b-o', label='Gauss O(n³)', linewidth=2)
ax2.semilogy(n_vals, ops_t, 'r-s', label='Thomas O(n)', linewidth=2)
ax2.set_xlabel('n (ukuran sistem)')
ax2.set_ylabel('Jumlah Operasi (log scale)')
ax2.set_title('Perbandingan (Log Scale)')
ax2.legend()
ax2.grid(True, alpha=0.4)

plt.tight_layout()
plt.savefig('figures/fig11_23_operations.png', dpi=120)
plt.show()
print("\nPlot disimpan ke figures/fig11_23_operations.png")
print("=" * 50)
