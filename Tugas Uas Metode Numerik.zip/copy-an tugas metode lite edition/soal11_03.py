"""
Soal 11.3 - Thomas Algorithm untuk Sistem Crank-Nicolson
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Selesaikan sistem tridiagonal berikut dengan Thomas Algorithm:

[ 2.01475  -0.020875   0          0       ] [T1]   [4.175 ]
[-0.020875  2.01475  -0.020875    0       ] [T2] = [0     ]
[ 0        -0.020875  2.01475  -0.020875  ] [T3]   [0     ]
[ 0         0        -0.020875  2.01475   ] [T4]   [2.0875]
"""

import numpy as np


def thomas_algorithm(a, b, c, d):
    """Solusi tridiagonal dengan Thomas Algorithm."""
    n = len(d)
    b = list(b)
    d = list(d)

    # Forward elimination
    for i in range(1, n):
        factor = a[i - 1] / b[i - 1]
        b[i] -= factor * c[i - 1]
        d[i] -= factor * d[i - 1]

    # Back substitution
    x = [0.0] * n
    x[-1] = d[-1] / b[-1]
    for i in range(n - 2, -1, -1):
        x[i] = (d[i] - c[i] * x[i + 1]) / b[i]

    return np.array(x)


# ── Data soal ────────────────────────────────────────
n = 4
diag  = [2.01475] * n
sub   = [-0.020875] * (n - 1)   # subdiagonal
sup   = [-0.020875] * (n - 1)   # superdiagonal
rhs   = [4.175, 0.0, 0.0, 2.0875]

# ── Solusi ───────────────────────────────────────────
T = thomas_algorithm(sub, diag, sup, rhs)

print("=" * 50)
print("Soal 11.3 — Thomas Algorithm (Crank-Nicolson)")
print("=" * 50)
print("\nSolusi T:")
for i, Ti in enumerate(T, 1):
    print(f"  T{i} = {Ti:.6f}")

# Verifikasi
A = (np.diag([2.01475]*4)
   + np.diag([-0.020875]*3, 1)
   + np.diag([-0.020875]*3, -1))
b = np.array([4.175, 0.0, 0.0, 2.0875])
T_np = np.linalg.solve(A, b)
print("\nVerifikasi numpy:")
for i, Ti in enumerate(T_np, 1):
    print(f"  T{i} = {Ti:.6f}")
print(f"\nSelisih max: {np.max(np.abs(T - T_np)):.2e}")
print("=" * 50)
