"""
Soal 11.1 - Thomas Algorithm (Tridiagonal System)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Selesaikan sistem tridiagonal berikut menggunakan Thomas Algorithm:
[ 0.8  -0.4   0  ] [x1]   [ 41 ]
[-0.4   0.8  -0.4] [x2] = [ 25 ]
[ 0    -0.4   0.8] [x3]   [105 ]

(a) Gunakan Thomas Algorithm
(b) Verifikasi dengan numpy.linalg.solve
"""

import numpy as np


def thomas_algorithm(a, b, c, d):
    """
    Solusi sistem tridiagonal menggunakan Thomas Algorithm.

    Parameter:
        a : list/array subdiagonal (panjang n-1)
        b : list/array diagonal utama (panjang n)
        c : list/array superdiagonal (panjang n-1)
        d : list/array vektor RHS (panjang n)

    Return:
        x : array solusi
    """
    n = len(d)
    # Salin agar tidak mengubah input asli
    b = list(b)
    d = list(d)

    # Forward elimination
    for i in range(1, n):
        factor = a[i - 1] / b[i - 1]
        b[i] -= factor * c[i - 1]
        d[i] -= factor * d[i - 1]

    # Back substitution
    x = [0.0] * n
    x[-1] = d[-1] / b[-1]
    for i in range(n - 2, -1, -1):
        x[i] = (d[i] - c[i] * x[i + 1]) / b[i]

    return np.array(x)


# ── Data soal ────────────────────────────────────────
# Subdiagonal, diagonal, superdiagonal, RHS
a = [-0.4, -0.4]       # subdiagonal (n-1 elemen)
b = [0.8, 0.8, 0.8]    # diagonal utama
c = [-0.4, -0.4]       # superdiagonal (n-1 elemen)
d = [41, 25, 105]      # vektor RHS

# ── (a) Thomas Algorithm ─────────────────────────────
x = thomas_algorithm(a, b, c, d)
print("=" * 45)
print("Soal 11.1 — Thomas Algorithm")
print("=" * 45)
print("\n(a) Solusi dengan Thomas Algorithm:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.6f}")

# ── (b) Verifikasi dengan numpy ──────────────────────
A = np.array([
    [ 0.8, -0.4,  0.0],
    [-0.4,  0.8, -0.4],
    [ 0.0, -0.4,  0.8]
])
b_vec = np.array([41, 25, 105], dtype=float)
x_np = np.linalg.solve(A, b_vec)

print("\n(b) Verifikasi dengan numpy.linalg.solve:")
for i, xi in enumerate(x_np, 1):
    print(f"  x{i} = {xi:.6f}")

print(f"\nSelisih max: {np.max(np.abs(x - x_np)):.2e}")
print("=" * 45)
