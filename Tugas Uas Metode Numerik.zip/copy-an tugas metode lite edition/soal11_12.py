"""
Soal 11.12 - Gauss-Seidel dengan dan tanpa Relaxation
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Gunakan Gauss-Seidel (a) tanpa relaxation dan (b) dengan λ = 0.95
untuk menyelesaikan sistem berikut (εs = 5%).
Jika perlu, susun ulang persamaan agar konvergen.

-3x1 +  x2 + 12x3 = 50
 6x1 -  x2 -   x3 =  3
 6x1 + 9x2 +   x3 = 40
"""

import numpy as np


def gauss_seidel_sor(A, b, tol=5.0, max_iter=200, lam=1.0):
    n = len(b)
    x = np.zeros(n)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x_gs = (b[i] - sigma) / A[i, i]
            x[i] = lam * x_gs + (1 - lam) * x_old[i]

        err = np.max(np.abs((x - x_old) / (x + 1e-15))) * 100
        history.append({'iter': it, 'x': x.copy(), 'err': err})

        if err < tol:
            return x, history, True

    return x, history, False


# ── Data soal (asli — perlu reorder agar diagonal dominant) ──
# Urutan asli tidak diagonal dominant, susun ulang:
#   Persamaan 2 → baris 1: 6x1 -  x2 -  x3 = 3    (dominan di x1)
#   Persamaan 3 → baris 2: 6x1 + 9x2 +  x3 = 40   (dominan di x2)
#   Persamaan 1 → baris 3: -3x1 + x2 + 12x3 = 50  (dominan di x3)

A = np.array([
    [ 6, -1, -1],
    [ 6,  9,  1],
    [-3,  1, 12]
], dtype=float)
b = np.array([3, 40, 50], dtype=float)

print("=" * 60)
print("Soal 11.12 — Gauss-Seidel ± Relaxation (λ=0.95, εs=5%)")
print("=" * 60)
print("\nSistem setelah diatur ulang (agar diagonal dominant):")
print("  6x1 -  x2 -   x3 =  3")
print("  6x1 + 9x2 +   x3 = 40")
print(" -3x1 +  x2 + 12x3 = 50")

# (a) Tanpa relaxation
print("\n(a) Tanpa relaxation (λ=1.0):")
x_a, hist_a, conv_a = gauss_seidel_sor(A, b, tol=5.0, lam=1.0)
print(f"    Konvergen: {conv_a} | Iterasi: {len(hist_a)}")
for i, xi in enumerate(x_a, 1):
    print(f"    x{i} = {xi:.4f}")

# (b) Dengan relaxation λ=0.95
print("\n(b) Dengan relaxation (λ=0.95):")
x_b, hist_b, conv_b = gauss_seidel_sor(A, b, tol=5.0, lam=0.95)
print(f"    Konvergen: {conv_b} | Iterasi: {len(hist_b)}")
for i, xi in enumerate(x_b, 1):
    print(f"    x{i} = {xi:.4f}")

# Solusi eksak
x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for i, xi in enumerate(x_exact, 1):
    print(f"  x{i} = {xi:.4f}")
print("=" * 60)
