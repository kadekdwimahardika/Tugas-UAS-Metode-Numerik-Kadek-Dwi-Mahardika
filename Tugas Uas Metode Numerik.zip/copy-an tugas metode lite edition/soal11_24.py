"""
Soal 11.24 - Program Thomas Algorithm (User-Friendly)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Buat program untuk menyelesaikan sistem tridiagonal dengan Thomas Algorithm.
Uji dengan menduplikasi hasil Example 11.1.

Example 11.1:
[ 2.04  -1      0      0    ] [T1]   [40.8]
[-1     2.04   -1      0    ] [T2] = [0.8 ]
[ 0    -1      2.04   -1    ] [T3]   [0.8 ]
[ 0     0     -1      2.04  ] [T4]   [200.8]
"""

import numpy as np


def thomas_solver(lower, main, upper, rhs, verbose=False):
    """
    Selesaikan sistem tridiagonal Ax = b dengan Thomas Algorithm.

    Parameter:
        lower : array subdiagonal (n-1 elemen)
        main  : array diagonal utama (n elemen)
        upper : array superdiagonal (n-1 elemen)
        rhs   : array vektor RHS (n elemen)
        verbose: tampilkan langkah detail

    Return:
        x : array solusi
    """
    n = len(rhs)
    # Salin agar tidak modifikasi input
    e = list(lower)
    f = list(main)
    g = list(upper)
    r = list(rhs)

    if verbose:
        print("\n--- Forward Elimination ---")

    # Forward elimination
    for i in range(1, n):
        factor = e[i - 1] / f[i - 1]
        f[i] = f[i] - factor * g[i - 1]
        r[i] = r[i] - factor * r[i - 1]
        if verbose:
            print(f"  Step {i}: factor={factor:.4f}, f[{i}]={f[i]:.4f}, r[{i}]={r[i]:.4f}")

    # Back substitution
    if verbose:
        print("\n--- Back Substitution ---")
    x = [0.0] * n
    x[-1] = r[-1] / f[-1]
    if verbose:
        print(f"  x[{n}] = {x[-1]:.4f}")
    for i in range(n - 2, -1, -1):
        x[i] = (r[i] - g[i] * x[i + 1]) / f[i]
        if verbose:
            print(f"  x[{i+1}] = {x[i]:.4f}")

    return np.array(x)


# ── Test: Example 11.1 dari buku ─────────────────────
print("=" * 55)
print("Soal 11.24 — Thomas Algorithm (User-Friendly)")
print("=" * 55)
print("\nTest dengan Example 11.1:")

n = 4
main  = [2.04, 2.04, 2.04, 2.04]
lower = [-1.0, -1.0, -1.0]
upper = [-1.0, -1.0, -1.0]
rhs   = [40.8, 0.8, 0.8, 200.8]

x = thomas_solver(lower, main, upper, rhs, verbose=True)

print("\nSolusi (Thomas Algorithm):")
for i, xi in enumerate(x, 1):
    print(f"  T{i} = {xi:.4f}")

# Verifikasi dengan numpy
A = (np.diag(main)
    + np.diag(lower, -1)
    + np.diag(upper, 1))
x_np = np.linalg.solve(A, np.array(rhs))
print("\nVerifikasi (numpy):")
for i, xi in enumerate(x_np, 1):
    print(f"  T{i} = {xi:.4f}")

print(f"\nSelisih max: {np.max(np.abs(x - x_np)):.2e}")
print("=" * 55)
