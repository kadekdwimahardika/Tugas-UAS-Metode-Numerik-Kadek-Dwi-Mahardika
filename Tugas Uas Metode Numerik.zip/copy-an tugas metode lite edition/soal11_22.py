"""
Soal 11.22 - Susun dan Selesaikan Sistem Linear
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Tuliskan dalam bentuk matriks dan selesaikan:
  50 = 5x3 - 7x2
  4x2 + 7x3 + 30 = 0
  x1 - 7x3 = 40 - 3x2 + 5x1

Juga hitung transpose dan invers matriks koefisien.
"""

import numpy as np

print("=" * 55)
print("Soal 11.22 — Setup dan Solve Sistem Linear")
print("=" * 55)

print("""
Langkah: Susun ulang tiap persamaan ke bentuk standar:

Pers 1: 50 = 5x3 - 7x2
  →  0·x1 - 7·x2 + 5·x3 = 50

Pers 2: 4x2 + 7x3 + 30 = 0
  →  0·x1 + 4·x2 + 7·x3 = -30

Pers 3: x1 - 7x3 = 40 - 3x2 + 5x1
  →  x1 - 5x1 + 3x2 - 7x3 = 40
  → -4x1 + 3x2 - 7x3 = 40
""")

# ── Matriks koefisien ────────────────────────────────
A = np.array([
    [ 0, -7,  5],
    [ 0,  4,  7],
    [-4,  3, -7]
], dtype=float)
b = np.array([50, -30, 40], dtype=float)

print("Matriks koefisien A:")
print(A)
print(f"\nVektor b: {b}")

# Solve
x = np.linalg.solve(A, b)
print(f"\nSolusi:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.6f}")

# Transpose
A_T = A.T
print(f"\nTranspose A^T:")
print(A_T)

# Inverse
A_inv = np.linalg.inv(A)
print(f"\nInvers A^(-1):")
print(np.round(A_inv, 6))

# Verifikasi
print(f"\nVerifikasi A @ x = b:")
print(f"  A @ x = {np.round(A @ x, 4)}")
print(f"  b     = {b}")
print("=" * 55)
