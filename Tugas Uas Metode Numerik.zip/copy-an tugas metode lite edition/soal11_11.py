"""
Soal 11.11 - Gauss-Seidel
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Gunakan Gauss-Seidel hingga error relatif < εs = 5%:
10x1 +  2x2 -   x3 =  27
-3x1 -  6x2 +  2x3 = -61.5
  x1 +   x2 +  5x3 = -21.5
"""

import numpy as np


def gauss_seidel(A, b, tol=5.0, max_iter=100):
    n = len(b)
    x = np.zeros(n)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x[i] = (b[i] - sigma) / A[i, i]

        err = np.max(np.abs((x - x_old) / (x + 1e-15))) * 100
        history.append({'iter': it, 'x': x.copy(), 'err': err})

        if err < tol:
            print(f"  Konvergen pada iterasi {it}, error = {err:.4f}%")
            break

    return x, history


# ── Data soal ────────────────────────────────────────
A = np.array([
    [10,  2, -1],
    [-3, -6,  2],
    [ 1,  1,  5]
], dtype=float)
b = np.array([27, -61.5, -21.5])

print("=" * 55)
print("Soal 11.11 — Gauss-Seidel (εs = 5%)")
print("=" * 55)

# Cek diagonal dominance
diag_dom = all(abs(A[i, i]) >= sum(abs(A[i, j]) for j in range(3) if j != i)
               for i in range(3))
print(f"\nDiagonal dominant? {diag_dom}")

print("\nIterasi:")
x, history = gauss_seidel(A, b, tol=5.0)

print(f"\n{'Iter':>4}  {'x1':>12}  {'x2':>12}  {'x3':>12}  {'Error%':>10}")
print("-" * 57)
for h in history:
    print(f"{h['iter']:>4}  {h['x'][0]:>12.4f}  {h['x'][1]:>12.4f}  {h['x'][2]:>12.4f}  {h['err']:>10.4f}")

print("\nSolusi akhir:")
for i, xi in enumerate(x, 1):
    print(f"  x{i} = {xi:.4f}")

x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for i, xi in enumerate(x_exact, 1):
    print(f"  x{i} = {xi:.4f}")
print("=" * 55)
