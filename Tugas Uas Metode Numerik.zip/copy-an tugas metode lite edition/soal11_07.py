"""
Soal 11.7 - Cholesky Decomposition Matriks Diagonal
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Hitung Cholesky decomposition dari:
[A] = [9  0  0]
      [0 25  0]
      [0  0  4]

Apakah hasilnya masuk akal dilihat dari Eq. (11.3) dan (11.4)?
"""

import numpy as np


def cholesky_decompose(A):
    n = A.shape[0]
    L = np.zeros((n, n), dtype=float)
    for k in range(n):
        L[k, k] = np.sqrt(A[k, k] - np.sum(L[k, :k]**2))
        for i in range(k + 1, n):
            L[i, k] = (A[i, k] - np.sum(L[i, :k] * L[k, :k])) / L[k, k]
    return L


# ── Data soal ────────────────────────────────────────
A = np.array([
    [9,  0, 0],
    [0, 25, 0],
    [0,  0, 4]
], dtype=float)

L = cholesky_decompose(A)

print("=" * 55)
print("Soal 11.7 — Cholesky Decomposition Matriks Diagonal")
print("=" * 55)
print("\nMatriks A (diagonal):")
print(A)
print("\nMatriks L hasil Cholesky:")
print(L)
print("\nVerifikasi L @ L^T:")
print(L @ L.T)

print("""
Analisis (Eq. 11.3 & 11.4):
  Karena A diagonal, semua elemen off-diagonal A[i,k] = 0.
  Eq. 11.3 → L[i,k] = 0 untuk i != k  (tidak ada elemen off-diagonal)
  Eq. 11.4 → L[k,k] = sqrt(A[k,k])

  Hasilnya:
    L[1,1] = sqrt(9)  = 3
    L[2,2] = sqrt(25) = 5
    L[3,3] = sqrt(4)  = 2

  → L adalah matriks diagonal dengan elemen = akar kuadrat diagonal A.
  → Ini masuk akal: Cholesky dari diagonal matrix = sqrt elemen diagonal.
""")
print("=" * 55)
