"""
Soal 11.27 - ODE ke Sistem Linear (Kanal 1D)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
ODE persamaan massa untuk zat kimia dalam kanal 1D:
  0 = D * d²c/dx² - U * dc/dx - k*c

Dengan: D=2, U=1, k=0.2, c(0)=80, c(10)=20
Diskritisasi dengan finite difference, selesaikan dari x=0 sampai x=10.
Plot konsentrasi vs jarak.
"""

import numpy as np
import matplotlib.pyplot as plt

# ── Parameter ────────────────────────────────────────
D = 2.0   # diffusion coefficient
U = 1.0   # fluid velocity
k = 0.2   # decay rate
c0 = 80.0  # c(0)
cL = 20.0  # c(10)
L = 10.0
n = 10     # jumlah interval internal

# ── Diskritisasi finite difference ───────────────────
# Bagi [0,10] menjadi n+1 segmen, ada n-1 titik interior
n_pts = n - 1  # titik interior
dx = L / n

# 0 = D*(c[i-1] - 2c[i] + c[i+1])/dx² - U*(c[i+1] - c[i-1])/(2dx) - k*c[i]
# Koefisien:
a = D / dx**2 + U / (2*dx)   # koefisien c[i-1]
b_coef = -2*D / dx**2 - k    # koefisien c[i]  (diagonal)
c_coef = D / dx**2 - U / (2*dx)  # koefisien c[i+1]

print("=" * 60)
print("Soal 11.27 — ODE → Sistem Linear (Kanal 1D)")
print("=" * 60)
print(f"\nParameter: D={D}, U={U}, k={k}, dx={dx}")
print(f"Koefisien: a={a:.4f}, b={b_coef:.4f}, c={c_coef:.4f}")

# Bangun matriks tridiagonal
A = np.zeros((n_pts, n_pts))
rhs = np.zeros(n_pts)

for i in range(n_pts):
    A[i, i] = b_coef
    if i > 0:
        A[i, i-1] = a
    if i < n_pts - 1:
        A[i, i+1] = c_coef

# Kondisi batas masuk ke RHS
rhs[0] -= a * c0
rhs[-1] -= c_coef * cL

# ── Solve ────────────────────────────────────────────
c_interior = np.linalg.solve(A, rhs)

# Gabungkan dengan batas
x_vals = np.linspace(0, L, n + 1)
c_full = np.concatenate([[c0], c_interior, [cL]])

print("\nHasil konsentrasi:")
print(f"{'x':>6}  {'c(x)':>12}")
print("-" * 20)
for xi, ci in zip(x_vals, c_full):
    print(f"{xi:>6.1f}  {ci:>12.4f}")

# ── Plot ─────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(x_vals, c_full, 'b-o', linewidth=2, markersize=7, label='Solusi numerik')
ax.scatter([0, L], [c0, cL], color='red', zorder=5, s=100, label='Kondisi batas')
ax.set_xlabel('Jarak x')
ax.set_ylabel('Konsentrasi c(x)')
ax.set_title('Soal 11.27: Distribusi Konsentrasi dalam Kanal 1D\n'
             f'D={D}, U={U}, k={k}')
ax.legend()
ax.grid(True, alpha=0.4)
plt.tight_layout()
plt.savefig('figures/fig11_27_concentration.png', dpi=120)
plt.show()
print("\nPlot disimpan ke figures/fig11_27_concentration.png")
print("=" * 60)
