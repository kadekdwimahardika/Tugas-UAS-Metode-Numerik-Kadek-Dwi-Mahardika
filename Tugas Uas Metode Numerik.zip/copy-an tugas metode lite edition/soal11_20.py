"""
Soal 11.20 - Vandermonde Matrix Condition Number
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Ulangi Soal 11.19 tetapi untuk matriks Vandermonde 6x6
dengan x1=4, x2=2, x3=7, x4=10, x5=3, x6=5.
"""

import numpy as np


def vandermonde_matrix(x_vals):
    """
    Buat matriks Vandermonde n x n:
    V[i,j] = x_i^(n-1-j)  (urutan menurun dari kiri ke kanan)
    """
    n = len(x_vals)
    V = np.zeros((n, n))
    for i, xi in enumerate(x_vals):
        for j in range(n):
            V[i, j] = xi ** (n - 1 - j)
    return V


x_vals = [4, 2, 7, 10, 3, 5]
V = vandermonde_matrix(x_vals)

# RHS: jumlah koefisien tiap baris → solusi x = [1,1,...,1]
b = V.sum(axis=1)

print("=" * 60)
print("Soal 11.20 — Vandermonde Matrix 6x6 Condition Number")
print("=" * 60)
print(f"\nx values: {x_vals}")
print(f"\nMatriks Vandermonde V:")
print(np.round(V, 2))

cond = np.linalg.cond(V)
digits_lost = np.log10(cond)

print(f"\nSpectral condition number: {cond:.4e}")
print(f"Digit presisi yang hilang: ~{digits_lost:.1f} digit")

x = np.linalg.solve(V, b)
x_exact = np.ones(6)
error = np.abs(x - x_exact)

print(f"\nSolusi x (harus = 1 semua):")
print(f"  x = {np.round(x, 6)}")
print(f"\nError |x - 1|:")
print(f"  max error = {error.max():.4e}")
print(f"  mean error = {error.mean():.4e}")

print(f"""
Perbandingan dengan Hilbert 10x10 (dari soal 11.19):
  Vandermonde cond ≈ {cond:.2e}
  Vandermonde lebih/kurang ill-conditioned tergantung nilai x.
""")
print("=" * 60)
