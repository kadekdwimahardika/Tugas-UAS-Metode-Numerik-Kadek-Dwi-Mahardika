"""
Soal 11.18 - Produksi Elektronik (Linear System)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Setiap transistor  butuh: 4 tembaga, 1 seng, 2 kaca
Setiap resistor    butuh: 3 tembaga, 3 seng, 1 kaca
Setiap chip        butuh: 2 tembaga, 1 seng, 3 kaca

Minggu ini tersedia: 960 tembaga, 510 seng, 610 kaca.
Berapa transistor (T), resistor (R), chip (C) yang diproduksi?
"""

import numpy as np

# ── Setup sistem persamaan ───────────────────────────
# 4T + 3R + 2C = 960  (tembaga)
# 1T + 3R + 1C = 510  (seng)
# 2T + 1R + 3C = 610  (kaca)

A = np.array([
    [4, 3, 2],
    [1, 3, 1],
    [2, 1, 3]
], dtype=float)

b = np.array([960, 510, 610], dtype=float)

print("=" * 55)
print("Soal 11.18 — Produksi Elektronik")
print("=" * 55)
print("\nSistem persamaan:")
print("  4T + 3R + 2C = 960  (tembaga)")
print("  1T + 3R + 1C = 510  (seng)")
print("  2T + 1R + 3C = 610  (kaca)")

x = np.linalg.solve(A, b)
T, R, C = x

print(f"\nSolusi produksi minggu ini:")
print(f"  Transistor (T) = {T:.1f} unit")
print(f"  Resistor   (R) = {R:.1f} unit")
print(f"  Chip       (C) = {C:.1f} unit")

# Verifikasi
check = A @ x
print(f"\nVerifikasi material yang digunakan:")
print(f"  Tembaga: {check[0]:.1f} (tersedia: 960)")
print(f"  Seng   : {check[1]:.1f} (tersedia: 510)")
print(f"  Kaca   : {check[2]:.1f} (tersedia: 610)")
print(f"\nSemua material habis tepat: {np.allclose(check, b)}")
print("=" * 55)
