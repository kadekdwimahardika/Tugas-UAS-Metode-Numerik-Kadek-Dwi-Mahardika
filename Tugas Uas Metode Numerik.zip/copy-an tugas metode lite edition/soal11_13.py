"""
Soal 11.13 - Gauss-Seidel dengan dan tanpa Relaxation (λ=1.2)
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Gunakan Gauss-Seidel (a) tanpa relaxation dan (b) dengan λ = 1.2
untuk menyelesaikan sistem berikut (εs = 5%).

 2x1 - 6x2 -  x3 = -38
-3x1 -  x2 + 7x3 = -34
-8x1 +  x2 - 2x3 = -20
"""

import numpy as np


def gauss_seidel_sor(A, b, tol=5.0, max_iter=200, lam=1.0):
    n = len(b)
    x = np.zeros(n)
    history = []

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x_gs = (b[i] - sigma) / A[i, i]
            x[i] = lam * x_gs + (1 - lam) * x_old[i]

        err = np.max(np.abs((x - x_old) / (x + 1e-15))) * 100
        history.append({'iter': it, 'x': x.copy(), 'err': err})
        if err < tol:
            return x, history, True

    return x, history, False


# ── Susun ulang agar diagonal dominant ───────────────
# Baris 3 jadi baris 1: -8x1 + x2 - 2x3 = -20  → dominan x1
# Baris 1 jadi baris 2:  2x1 - 6x2 - x3 = -38  → dominan x2
# Baris 2 jadi baris 3: -3x1 - x2 + 7x3 = -34  → dominan x3

A = np.array([
    [-8,  1, -2],
    [ 2, -6, -1],
    [-3, -1,  7]
], dtype=float)
b = np.array([-20, -38, -34], dtype=float)

print("=" * 60)
print("Soal 11.13 — Gauss-Seidel ± Relaxation (λ=1.2, εs=5%)")
print("=" * 60)
print("\nSistem setelah diatur ulang:")
print(" -8x1 +  x2 - 2x3 = -20")
print("  2x1 - 6x2 -  x3 = -38")
print(" -3x1 -  x2 + 7x3 = -34")

# (a) Tanpa relaxation
print("\n(a) Tanpa relaxation (λ=1.0):")
x_a, hist_a, conv_a = gauss_seidel_sor(A, b, tol=5.0, lam=1.0)
print(f"    Konvergen: {conv_a} | Iterasi: {len(hist_a)}")
for i, xi in enumerate(x_a, 1):
    print(f"    x{i} = {xi:.4f}")

# (b) Dengan relaxation λ=1.2
print("\n(b) Dengan overrelaxation (λ=1.2):")
x_b, hist_b, conv_b = gauss_seidel_sor(A, b, tol=5.0, lam=1.2)
print(f"    Konvergen: {conv_b} | Iterasi: {len(hist_b)}")
for i, xi in enumerate(x_b, 1):
    print(f"    x{i} = {xi:.4f}")

x_exact = np.linalg.solve(A, b)
print("\nSolusi eksak:")
for i, xi in enumerate(x_exact, 1):
    print(f"  x{i} = {xi:.4f}")
print("=" * 60)
