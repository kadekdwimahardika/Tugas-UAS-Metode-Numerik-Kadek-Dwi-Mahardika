"""
Soal 11.21 - Augmented Matrix [A | I]
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Diberikan matriks persegi [A], buat perintah SATU BARIS
(MATLAB: [Aug] = [A, eye(size(A))]) yang menghasilkan
matriks [A] yang di-augment dengan matriks identitas [I].

Jawaban Python:
  Aug = np.hstack([A, np.eye(A.shape[0])])
"""

import numpy as np

# Contoh matriks A (bisa diganti dengan ukuran apapun)
A = np.array([
    [2, 1, -1],
    [-3, -1, 2],
    [-2, 1, 2]
], dtype=float)

print("=" * 55)
print("Soal 11.21 — Augmented Matrix [A | I]")
print("=" * 55)

print("\nMatriks A:")
print(A)

# ── Perintah satu baris (ekuivalen MATLAB) ───────────
Aug = np.hstack([A, np.eye(A.shape[0])])

print("\nAugmented matrix [A | I] (satu baris Python):")
print("  Aug = np.hstack([A, np.eye(A.shape[0])])")
print()
print(Aug)

print("""
Catatan:
  MATLAB : [Aug] = [A, eye(size(A))]
  Python  : Aug = np.hstack([A, np.eye(A.shape[0])])

  Matriks augmented ini digunakan dalam eliminasi Gauss-Jordan
  untuk menghitung invers: [A | I] → [I | A^-1]
""")

# Bonus: hitung invers via Gauss-Jordan dari augmented
A_inv = np.linalg.inv(A)
print("Invers A (verifikasi):")
print(np.round(A_inv, 6))
print("=" * 55)
