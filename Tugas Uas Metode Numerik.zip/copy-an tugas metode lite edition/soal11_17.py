"""
Soal 11.17 - Sistem Nonlinear dengan scipy.optimize
Buku: Numerical Methods for Engineers, Chapra & Canale

Soal:
Diberikan sepasang persamaan nonlinear:
  f(x,y) = 4 - y - 2x²
  g(x,y) = 8 - y² - 4x

(a) Temukan dua pasang (x,y) yang memenuhi f=0 dan g=0.
(b) Dengan rentang initial guess x = [-6,6] dan y = [-6,6],
    tentukan tebakan mana yang menghasilkan solusi mana.
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt


def equations(vars):
    x, y = vars
    f = 4 - y - 2*x**2
    g = 8 - y**2 - 4*x
    return [f, g]


print("=" * 55)
print("Soal 11.17 — Sistem Nonlinear (SciPy fsolve)")
print("=" * 55)

# (a) Cari semua solusi dengan berbagai initial guess
solutions = []
for x0 in np.linspace(-6, 6, 25):
    for y0 in np.linspace(-6, 6, 25):
        try:
            sol = fsolve(equations, [x0, y0], full_output=True)
            x_sol, info, ier, msg = sol
            if ier == 1:  # konvergen
                res = np.max(np.abs(equations(x_sol)))
                if res < 1e-8:
                    # Cek duplikat
                    is_new = all(np.linalg.norm(x_sol - s) > 1e-4 for s in solutions)
                    if is_new:
                        solutions.append(x_sol)
        except Exception:
            pass

print(f"\n(a) Ditemukan {len(solutions)} solusi:")
for i, s in enumerate(solutions, 1):
    print(f"  Solusi {i}: x = {s[0]:.6f}, y = {s[1]:.6f}")
    # Verifikasi
    f_val = 4 - s[1] - 2*s[0]**2
    g_val = 8 - s[1]**2 - 4*s[0]
    print(f"    f(x,y) = {f_val:.2e}, g(x,y) = {g_val:.2e}")

# (b) Peta konvergensi
print("\n(b) Peta konvergensi (plot basin of attraction)...")
N = 60
x_range = np.linspace(-6, 6, N)
y_range = np.linspace(-6, 6, N)
basin = np.zeros((N, N))

for i, x0 in enumerate(x_range):
    for j, y0 in enumerate(y_range):
        try:
            sol = fsolve(equations, [x0, y0], full_output=True)
            x_sol, _, ier, _ = sol
            if ier == 1 and np.max(np.abs(equations(x_sol))) < 1e-6:
                # Identifikasi solusi mana
                for k, s in enumerate(solutions):
                    if np.linalg.norm(x_sol - s) < 0.1:
                        basin[j, i] = k + 1
                        break
        except Exception:
            pass

plt.figure(figsize=(7, 6))
plt.contourf(x_range, y_range, basin, levels=[-0.5, 0.5, 1.5, 2.5],
             colors=['white', 'skyblue', 'salmon'], alpha=0.8)
for i, s in enumerate(solutions, 1):
    plt.plot(s[0], s[1], 'k*', markersize=15, label=f"Solusi {i}: ({s[0]:.2f},{s[1]:.2f})")
plt.colorbar(label='Solusi')
plt.xlabel('x₀ (initial guess)')
plt.ylabel('y₀ (initial guess)')
plt.title('Basin of Attraction — Soal 11.17')
plt.legend(loc='upper right')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('figures/fig11_17_basin.png', dpi=120)
plt.show()
print("Plot disimpan ke figures/fig11_17_basin.png")
print("=" * 55)
